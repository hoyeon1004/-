package com.hoyeon.doomsday

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.time.Instant
import java.util.Locale
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin

// Marvel 공식 DOOMSDAY CLOCK의 동기화 기준: 2026-12-18 05:00:00 UTC
// 한국 시간으로는 2026-12-18 14:00:00 (KST). 기기 시간대와 무관하게 같은 순간을 가리킨다.
private val TARGET: Long = Instant.parse("2026-12-18T05:00:00Z").toEpochMilli()
private const val PREFS_NAME = "doomsday_settings"
private const val PREF_PRECISION_MODE = "precision_mode"
private val ACCENT: Int = 0xFF6B2428.toInt() // muted blood-red, no emissive glow
private val ASH: Int = 0xFFB7B0A4.toInt()

class SetActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.rgb(3, 3, 4)
        window.navigationBarColor = Color.rgb(3, 3, 4)

        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        var selected = if (prefs.getBoolean(PREF_PRECISION_MODE, false)) 1 else 0
        val modes = arrayOf("기본 초 단위", "0.00초 정밀 모드")

        // Android AlertDialog cannot show a message and a choice list at the same time.
        // Keep the instruction in the title and show the two actual selectable rows.
        val dialog = AlertDialog.Builder(this)
            .setTitle("DOOMSDAY CLOCK\n카운트다운 표시 방식을 선택하세요.")
            .setSingleChoiceItems(modes, selected) { _, which -> selected = which }
            .setPositiveButton("배경화면 설정") { _, _ ->
                prefs.edit().putBoolean(PREF_PRECISION_MODE, selected == 1).apply()
                startActivity(
                    Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                        WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        ComponentName(this, DoomsdayWallpaper::class.java)
                    )
                )
                finish()
            }
            .setNegativeButton("취소") { _, _ -> finish() }
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xFFB9AAA0.toInt())
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(0xFF8E8982.toInt())
        }
        dialog.setOnCancelListener { finish() }
        dialog.show()
    }
}

class DoomsdayWallpaper : WallpaperService() {
    override fun onCreateEngine(): Engine = DoomEngine()

    inner class DoomEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val tick = Runnable { draw() }
        private var visible = false
        private var w = 0
        private var h = 0
        private var precisionMode = this@DoomsdayWallpaper.getSharedPreferences(PREFS_NAME, android.content.Context.MODE_PRIVATE)
            .getBoolean(PREF_PRECISION_MODE, false)
        private var idleBg: Bitmap? = null
        private var idleBlur: Bitmap? = null
        private var revealBg: Bitmap? = null
        private var revealBlur: Bitmap? = null
        private var shWhite: Shader? = null
        private var shGreen: Shader? = null

        private fun face(wt: Int): Typeface = try {
            Typeface.Builder(assets, "fonts/Cinzel.ttf").setFontVariationSettings("'wght' $wt").build() ?: Typeface.SERIF
        } catch (e: Exception) { Typeface.SERIF }
        private val fTitle = face(800)
        private val fNum = face(600)
        private val fLabel = face(500)

        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
        private val ap = Paint(Paint.FILTER_BITMAP_FLAG)
        private val dp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9BFFC0.toInt() }

        private fun load(name: String): Bitmap? {
            val id = resources.getIdentifier(name, "drawable", packageName)
            return if (id == 0) null else BitmapFactory.decodeResource(resources, id)
        }

        private fun compose(src: Bitmap?): Bitmap {
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            c.drawColor(Color.BLACK)
            if (src != null) {
                val s = max(w / src.width.toFloat(), h / src.height.toFloat())
                c.save()
                c.translate((w - src.width * s) / 2f, (h - src.height * s) * 0.25f)
                c.scale(s, s)
                c.drawBitmap(src, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
                c.restore()
                src.recycle()
            } else {
                val g = Paint().apply { shader = RadialGradient(w / 2f, h * 0.3f, h * 0.6f, 0x331A1514, Color.BLACK, Shader.TileMode.CLAMP) }
                c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), g)
            }
            val shade = Paint().apply { shader = LinearGradient(0f, h * 0.6f, 0f, h.toFloat(), Color.TRANSPARENT, 0xEE000000.toInt(), Shader.TileMode.CLAMP) }
            c.drawRect(0f, h * 0.6f, w.toFloat(), h.toFloat(), shade)
            val vig = Paint().apply { shader = RadialGradient(w / 2f, h / 2f, h * 0.75f, Color.TRANSPARENT, 0xE6000000.toInt(), Shader.TileMode.CLAMP) }
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), vig)
            return out
        }

        private fun blur(b: Bitmap): Bitmap {
            var s = b
            repeat(4) { s = Bitmap.createScaledBitmap(s, max(1, s.width / 2), max(1, s.height / 2), true) }
            return Bitmap.createScaledBitmap(s, w, h, true)
        }

        private fun ease(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3 - 2 * t) }
        private fun frac(x: Float) = x - floor(x)

        private fun bg(c: Canvas, b: Bitmap?, a: Float, s: Float) {
            if (b == null || a <= 0f) return
            ap.alpha = (255 * a.coerceAtMost(1f)).toInt()
            c.save(); c.scale(s, s, w / 2f, h * 0.45f); c.drawBitmap(b, 0f, 0f, ap); c.restore()
        }

        private fun fit(s: String, f: Typeface, sp: Float, maxW: Float, size: Float): Float {
            p.typeface = f; p.letterSpacing = sp; p.textSize = size
            val m = p.measureText(s)
            return if (m > maxW) size * maxW / m else size
        }

        private fun txt(
            c: Canvas, s: String, x: Float, y: Float, size: Float, sp: Float, f: Typeface, a: Int,
            color: Int = Color.WHITE, glow: Boolean = false, sh: Shader? = null, darkShadow: Boolean = false
        ) {
            p.typeface = f; p.textSize = size; p.letterSpacing = sp; p.color = color; p.shader = sh; p.alpha = a.coerceIn(0, 255)
            when {
                glow -> p.setShadowLayer(size * 0.10f, 0f, size * 0.025f, 0xCC000000.toInt())
                darkShadow -> p.setShadowLayer(size * 0.2f, 0f, size * 0.045f, 0xE6000000.toInt())
                else -> p.clearShadowLayer()
            }
            c.drawText(s, x + sp * size / 2f, y, p)
            p.shader = null
            p.clearShadowLayer()
        }

        private fun dust(c: Canvas, tm: Float, a: Float) {
            val u = w / 1080f
            for (i in 0 until 16) {
                val r1 = frac(sin(i * 12.9898f) * 43758.547f)
                val r2 = frac(sin(i * 78.233f) * 12345.678f)
                val r3 = frac(sin(i * 39.346f) * 9876.54f)
                val y = h * 1.05f - ((tm * (14 + 26 * r2) * 3 * u + r3 * h) % (h * 1.1f))
                val x = r1 * w + sin(tm * 0.5f + i) * 18 * u
                val tw = 0.5f + 0.5f * sin(tm * (0.8f + r2) + i)
                dp.color = 0xFF8D8982.toInt()
                dp.alpha = (42 * a * (0.3f + 0.35f * r3)).toInt()
                c.drawCircle(x, y, (1.2f + 2.8f * r3) * u, dp)
            }
        }

        private fun countdownFrame(c: Canvas, tm: Float, k: Float, precision: Boolean) {
            val u = w / 1080f
            val left = w * 0.045f
            val right = w * 0.955f
            val top = h * 0.055f
            val bottom = h * 0.285f
            val pulse = 0.5f
            val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = max(1f, 1.15f * u)
                color = 0x665B292B
                alpha = (95 + 45 * pulse).toInt()
            }
            val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(0f, top, 0f, bottom, 0x32101812, 0x16030906, Shader.TileMode.CLAMP)
            }
            c.drawRoundRect(left, top, right, bottom, 18f * u, 18f * u, fill)
            fill.shader = null
            c.drawRoundRect(left, top, right, bottom, 18f * u, 18f * u, edge)

            // Corner cuts and a restrained centerline make the readout feel like a cinematic instrument panel.
            val corner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x887C7770.toInt(); strokeWidth = 2.2f * u
                style = Paint.Style.STROKE; strokeCap = Paint.Cap.SQUARE
            }
            val len = 23f * u
            for (x in floatArrayOf(left + 13f * u, right - 13f * u)) {
                for (y in floatArrayOf(top + 13f * u, bottom - 13f * u)) {
                    val sx = if (x < w / 2f) 1f else -1f
                    val sy = if (y < h / 2f) 1f else -1f
                    c.drawLine(x, y, x + sx * len, y, corner)
                    c.drawLine(x, y, x, y + sy * len, corner)
                }
            }
            val headerY = top + 27f * u
            val header = "MARVEL STUDIOS   /   DOOMSDAY EVENT"
            txt(c, header, w / 2f, headerY, w * 0.019f, 0.24f, fLabel,
                (145 * k).toInt(), 0xFFC3BDB2.toInt())
            val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x554B2929; strokeWidth = 1f * u
            }
            c.drawLine(w * 0.22f, headerY + 10f * u, w * 0.78f, headerY + 10f * u, line)
            // Tiny live indicator, intentionally subtle rather than a distracting badge.
            val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFF71383A.toInt(); alpha = (130 * k).toInt()
            }
            c.drawCircle(w * 0.19f, headerY - 5f * u, 2.7f * u, dot)
            dot.clearShadowLayer()
        }

        private fun ui(c: Canvas, left: Long, k: Float, precision: Boolean = false) {
            if (k <= 0f) return
            val al = (255 * k).toInt()
            val nowForFx = System.currentTimeMillis() / 1000f
            countdownFrame(c, nowForFx, k, precision)
            // 메인 타이틀과 개봉일 표시는 기존 위치를 유지한다.
            val ty = h * 0.838f
            val tsz = fit("DOOMSDAY", fTitle, 0.45f, w * 0.62f, w * 0.075f)
            txt(c, "DOOMSDAY", w / 2f, ty, tsz, 0.45f, fTitle, al, 0xFFD0C8BA.toInt(), false)
            p.typeface = fTitle; p.textSize = tsz; p.letterSpacing = 0.45f
            val half = p.measureText("DOOMSDAY") / 2f
            p.color = 0xFF62514A.toInt(); p.alpha = (95 * k).toInt(); p.strokeWidth = 2f; p.clearShadowLayer()
            c.drawLine(w * 0.06f, ty - tsz * 0.35f, w / 2f - half - w * 0.03f, ty - tsz * 0.35f, p)
            c.drawLine(w / 2f + half + w * 0.03f, ty - tsz * 0.35f, w * 0.94f, ty - tsz * 0.35f, p)
            txt(c, "IN THEATERS  \u00B7  12.18.2026", w / 2f, ty + w * 0.05f, w * 0.026f, 0.3f, fLabel, (170 * k).toInt())

            val v = longArrayOf(left / 86400000, left / 3600000 % 24, left / 60000 % 60, left / 1000 % 60)
            val lab = arrayOf("DAYS", "HOURS", "MINUTES", "SECONDS")
            val sz = w * if (precision) 0.108f else 0.115f
            val cw = w * if (precision) 0.071f else 0.078f
            val gap = w * if (precision) 0.057f else 0.07f
            val decimalWidth = if (precision) w * 0.116f else 0f
            val totalWidth = 8f * cw + 3f * gap + decimalWidth
            val x0 = (w - totalWidth) / 2f
            // 카운트다운 숫자와 단위만 화면 위쪽으로 이동한다.
            val y = h * 0.181f
            val hundredths = if (precision) ((left.coerceAtLeast(0L) % 1000L) / 10L).toInt() else 0
            val since = if (left > 0) 1000 - left % 1000 else 1000L
            val pop = 1f + 0.16f * (1f - ease(since / 350f))

            for (g in 0..3) {
                val gx = x0 + g * (2f * cw + gap)
                val last = g == 3
                val s = String.format(Locale.US, "%02d", v[g])
                for (j in 0..1) {
                    val cx = gx + (j + 0.5f) * cw
                    c.save()
                    if (last) c.scale(pop, pop, cx, y - sz * 0.35f)
                    txt(
                        c, s.substring(j, j + 1), cx, y, sz, 0f, fNum, al,
                        0xFFE0DAD0.toInt(), false,
                        shWhite, darkShadow = true
                    )
                    c.restore()
                }

                if (last && precision) {
                    val decimalCenter = gx + 2f * cw + decimalWidth / 2f
                    c.save()
                    c.scale(pop, pop, decimalCenter, y - sz * 0.17f)
                    txt(
                        c, String.format(Locale.US, ".%02d", hundredths), decimalCenter, y - sz * 0.025f,
                        sz * 0.43f, 0f, fNum, al, 0xFFB9AAA0.toInt(), false, null, darkShadow = true
                    )
                    c.restore()
                }

                val labelCenter = gx + cw + if (last) decimalWidth / 2f else 0f
                txt(c, lab[g], labelCenter, y + w * 0.052f, w * 0.024f, 0.35f, fLabel, (150 * k).toInt())
                if (g < 3) {
                    val dx = gx + 2f * cw + gap / 2f
                    p.color = 0xFF766B62.toInt(); p.alpha = (155 * k).toInt(); p.clearShadowLayer()
                    c.drawCircle(dx, y - sz * 0.58f, w * 0.0042f, p)
                    c.drawCircle(dx, y - sz * 0.26f, w * 0.0042f, p)
                    p.clearShadowLayer()
                }
            }
        }

        // 블러 -> 암전 -> 블러 상태로 등장(서서히 줌아웃) -> 선명해지며 문구
        private fun released(c: Canvas, since: Long, tm: Float) {
            val t = since / 1000f
            val breathe = 1f + 0.02f * (0.5f + 0.5f * sin(tm / 6f))
            c.drawColor(Color.BLACK)
            if (t < 2.4f) {
                bg(c, idleBg, 1f, breathe)
                bg(c, idleBlur, ease(t / 1.2f), breathe)
                ui(c, 0, 1f - ease(t / 0.8f), false)
                c.drawColor(Color.argb((255 * ease((t - 1.2f) / 1.2f)).toInt(), 0, 0, 0))
            } else {
                val s = 1f + 0.07f * (1f - ease((t - 2.4f) / 4f))
                bg(c, revealBlur, ease((t - 2.4f) / 1.3f), s)
                bg(c, revealBg, ease((t - 3.2f) / 1.6f), s)
                dust(c, tm, ease((t - 3.5f) / 1.5f))
                val al = (255 * ease((t - 4.4f) / 1.2f)).toInt()
                val a1 = fit("IT'S", fTitle, 0.5f, w * 0.5f, w * 0.1f)
                val a2 = fit("DOOMSDAY.", fTitle, 0.1f, w * 0.88f, w * 0.14f)
                txt(c, "IT'S", w / 2f, h * 0.76f, a1, 0.5f, fTitle, al)
                txt(c, "DOOMSDAY.", w / 2f, h * 0.76f + a2 * 1.25f, a2, 0.1f, fTitle, al, 0xFFB7AAA0.toInt(), false)
            }
        }

        private fun draw() {
            handler.removeCallbacks(tick)
            if (!visible) return
            val c = try { surfaceHolder.lockHardwareCanvas() } catch (e: Exception) {
                try { surfaceHolder.lockCanvas() } catch (e2: Exception) { null }
            } ?: return
            try {
                val now = System.currentTimeMillis()
                val left = TARGET - now
                val tm = (now % 100000000L) / 1000f
                if (left > 0) {
                    bg(c, idleBg, 1f, 1f + 0.02f * (0.5f + 0.5f * sin(tm / 6f)))
                    ui(c, left, 1f, precisionMode)
                } else released(c, -left, tm)
            } finally {
                surfaceHolder.unlockCanvasAndPost(c)
            }
            // 기본 모드는 30fps, 정밀 모드는 최대 약 60fps로 갱신해 1/100초를 표시한다.
            handler.postDelayed(tick, if (precisionMode) 16L else 33L)
        }

        override fun onSurfaceChanged(sh: SurfaceHolder, format: Int, width: Int, height: Int) {
            w = width; h = height
            shWhite = LinearGradient(0f, h * 0.185f - w * 0.115f * 0.75f, 0f, h * 0.185f, 0xFFF0E8DC.toInt(), 0xFFAAA197.toInt(), Shader.TileMode.CLAMP)
            shGreen = LinearGradient(0f, h * 0.185f - w * 0.115f * 0.75f, 0f, h * 0.185f, 0xFFF0E8D9.toInt(), 0xFF9A8F83.toInt(), Shader.TileMode.CLAMP)
            idleBg = compose(load("doom_idle"))
            revealBg = compose(load("doom_reveal") ?: load("doom_idle"))
            idleBlur = blur(idleBg!!); revealBlur = blur(revealBg!!)
            draw()
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            if (v) {
                precisionMode = this@DoomsdayWallpaper.getSharedPreferences(PREFS_NAME, android.content.Context.MODE_PRIVATE).getBoolean(PREF_PRECISION_MODE, false)
                draw()
            } else handler.removeCallbacks(tick)
        }

        override fun onSurfaceDestroyed(sh: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(tick)
        }

        override fun onDestroy() {
            handler.removeCallbacks(tick)
        }
    }
}
