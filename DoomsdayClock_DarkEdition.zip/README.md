# Doomsday Clock — updated project

## Changes

- Countdown target now uses the fixed instant `2026-12-18T05:00:00Z` (2026-12-18 14:00:00 in Korea). It no longer interprets midnight in each device's current time zone.
- The countdown digits, separators and unit labels have moved to the upper portion of the wallpaper. The existing image, lower `DOOMSDAY` title, theatrical date, background motion and post-countdown reveal remain in place.
- The launcher now offers two display modes before opening Android's live-wallpaper preview:
  - **기본 초 단위** — normal seconds, 30 fps refresh.
  - **0.00초 정밀 모드** — hundredths of a second (`SS.xx`), requesting up to 60 fps (16 ms redraw interval).
- The selected mode is saved and restored when the app is opened again.

## Time reference

Marvel Entertainment's official live video is [AVENGERS: DOOMSDAY CLOCK](https://www.youtube.com/watch?v=f17J3AXVK5w). Marvel's official movie listing confirms the December 18, 2026 release date. The exact `05:00 UTC` instant is taken from a fan-made countdown page that explicitly describes itself as synchronized with the live countdown; Marvel's public movie listing itself does not publish an hour/minute release time. The wallpaper uses that synchronized instant as its fixed target.

At `2026-11-27 23:44:18 KST`, the exact remaining time to that target is:

`20 days 14 hours 15 minutes 42 seconds`

For comparison, at `2026-11-26 23:44:18 KST`, it is `21 days 14 hours 15 minutes 42 seconds`. This explains the one-day difference when the reference date changes.

## Build

The repository's GitHub Actions workflow uses JDK 17 and Gradle 8.7, then runs:

```bash
gradle assembleDebug
```

The current editing environment does not have the Android SDK or Gradle CLI installed, so an APK build/device run could not be performed here. The source and resource edits are included in this ZIP.

## Version 1.3 visual polish

- Added a restrained translucent instrument-panel frame around the upper countdown, with fine dark charcoal / muted blood-red edge lighting and precision corner marks.
- Added a compact `MARVEL STUDIOS / DOOMSDAY EVENT` header and a subtle pulsing live indicator.
- Added sparse, slowly drifting dark charcoal / muted blood-red/amber atmospheric particles for depth without obscuring the source artwork.
- Kept the original background artwork, countdown placement, lower DOOMSDAY title/date, reveal animation, and both timing modes.
- Bumped Android app version to 1.3 (versionCode 3).
